# Mini Issue Tracker — UX/UI MVP

Практична робота (індивідуальне виконання): редаговані low-fidelity wireframes і клікабельний прототип Mini Issue Tracker.

**Figma:** https://www.figma.com/design/B5nr6SR4YnQztz8cmqTPaa/Untitled?node-id=0-1&t=WWZYHXKmtHtdEB83-1

## Обсяг
US-01–US-08; US-09 (вкладення) відкладено; SR-10/11 (AI-функції) поза MVP.

## Структура
- `docs/01_Input_Pack.md` — вимоги та Source Check
- `docs/02_Screen_Map_Decision_Log.md` — карта екранів та UX-рішення
- `docs/03_Screen_Contracts_Traceability.md` — контракти, права та трасування
- `docs/04_Plan_Review.md` — перевірка плану
- `docs/05_Figma_Brief_v1.0.md` — самодостатній англомовний бриф
- `docs/06_Generation_Correction_Report.md` — генерація та виправлення
- `docs/07_Prototype_Test_Record.md` — ручні тести
- `docs/08_Final_Review_Defect_Change_Log.md` — підсумковий огляд
- `docs/09_AI_Interaction_Log.md` — застосування AI
- `evidence/` — 10 наданих студентом скриншотів екранів Figma

## Особливості прототипу
Figma демонструє статичні сценарії. Збереження даних, автентифікація, серверні права, HTTPS, backup та продуктивність не доведені цим прототипом. Непідтверджені тести позначені як **NOT VERIFIED**. Перед здачею перевірити посилання та вручну протестувати ще непідтверджені інтеракції.
